#!/bin/bash

rm BehavioralEconomics_*.tar.gz
rm -rf BehavioralEconomics.Rcheck
R CMD BUILD .
R CMD CHECK BehavioralEconomics_*.tar.gz
R CMD INSTALL BehavioralEconomics_*.tar.gz
