# Given parameters, how far are fitted parameters?

library('testthat')
library('BehavioralEconomics')

estimates <- data.frame()

for (n in c(10, 50, 100, 500))
{
  x1.range <- 10:20
  t1.range <- 0:5
  x2.range <- 10:30
  t2.range <- 0:10

  choices <- discounting.model.generate.choice.set(n, x1.range, t1.range, x2.range, t2.range)

  for (a in c(1, 5))
  {
    for (gamma in c(0.75, 1, 1.25))
    {
      for (delta in seq(0.1, 0.9, by = 0.1))
      {
        for (iteration in 1:25)
        {
          parameters <- list('a' = a, 'gamma' = gamma, 'delta' = delta)
          choices <- discounting.model.simulate(choices, 'exponential', parameters)
          fitted.parameters <- discounting.model.fit(choices, 'exponential')  
          estimates <- rbind(estimates,
                             data.frame(N = n,
                                        Iteration = iteration,
                                        TrueA = a,
                                        EstimatedA = fitted.parameters$a,
                                        TrueGamma = gamma,
                                        EstimatedGamma = fitted.parameters$gamma,
                                        TrueDelta = delta,
                                        EstimatedDelta = fitted.parameters$delta))
        }
      }
    }
  }
}

ggplot(estimates, aes(x = TrueA, y = EstimatedA)) +
  stat_summary(fun.data = 'mean_cl_boot', geom = 'errorbar') +
  facet_grid(N ~ .)

ggplot(estimates, aes(x = TrueGamma, y = EstimatedGamma)) +
  stat_summary(fun.data = 'mean_cl_boot', geom = 'errorbar') +
  facet_grid(N ~ .)

ggplot(estimates, aes(x = TrueDelta, y = EstimatedDelta)) +
  stat_summary(fun.data = 'mean_cl_boot', geom = 'errorbar') +
  facet_grid(N ~ .)
