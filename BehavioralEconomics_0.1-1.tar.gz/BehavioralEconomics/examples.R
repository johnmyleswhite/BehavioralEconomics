library('BehavioralEconomics')

n <- 100
x1.range <- 10:20
t1.range <- 0:5
x2.range <- 10:30
t2.range <- 0:10

parameters <- list('a' = 1, 'delta' = 0.9)
choices <- discounting.model.generate.choice.set(n, x1.range, t1.range, x2.range, t2.range)
choices <- discounting.model.simulate(choices, 'exponential', parameters)
curve(discounting.model.log.likelihood(choices,
                                       'exponential',
                                       list('a' = x, 'delta' = 0.9)),
      from = 0,
      to = 10)
curve(discounting.model.log.likelihood(choices,
                                       'exponential',
                                       list('a' = 1, 'delta' = x)),
      from = 0,
      to = 1)
# Heatmap / contour map

parameters <- list('a' = 1, 'k' = 0.33)
choices <- discounting.model.generate.choice.set(n, x1.range, t1.range, x2.range, t2.range)
choices <- discounting.model.simulate(choices, 'hyperbolic', parameters)
curve(discounting.model.log.likelihood(choices,
                                       'hyperbolic',
                                       list('a' = x, 'k' = 0.33)),
      from = 0,
      to = 10)
curve(discounting.model.log.likelihood(choices,
                                       'hyperbolic',
                                       list('a' = 1, 'k' = x)),
      from = 0,
      to = 10)

parameters <- discounting.model.fit(choices, 'exponential')
discounting.model.log.likelihood(choices, 'exponential', parameters)

parameters <- discounting.model.fit(choices, 'hyperbolic')
discounting.model.log.likelihood(choices, 'hyperbolic', parameters)

parameters <- discounting.model.fit(choices, 'concave-waiting')
discounting.model.log.likelihood(choices, 'concave-waiting', parameters)
